import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../db/db_helper.dart';
import '../../models/models.dart';
import '../../utils/theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/common_widgets.dart';
import 'add_transaction_screen.dart';

class RecordsScreen extends StatefulWidget {
  const RecordsScreen({super.key});

  @override
  State<RecordsScreen> createState() => _RecordsScreenState();
}

class _RecordsScreenState extends State<RecordsScreen> {
  DateTime _month = DateTime.now();
  List<Transaction> _transactions = [];
  double _expense = 0, _income = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final txs = await DBHelper.instance.getTransactions(
      month: _month.month,
      year: _month.year,
    );
    final summary = await DBHelper.instance.getMonthSummary(
      _month.month, _month.year);

    setState(() {
      _transactions = txs;
      _expense = summary['expense'] ?? 0;
      _income = summary['income'] ?? 0;
      _loading = false;
    });
  }

  Map<String, List<Transaction>> _groupByDate() {
    final Map<String, List<Transaction>> grouped = {};
    for (final tx in _transactions) {
      final key = DateFormat('yyyy-MM-dd').format(tx.date);
      grouped.putIfAbsent(key, () => []).add(tx);
    }
    return grouped;
  }

  Future<void> _openAdd() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AddTransactionScreen()),
    );
    if (result == true) _load();
  }

  Future<void> _openEdit(Transaction tx) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => AddTransactionScreen(existing: tx)),
    );
    if (result == true) _load();
  }

  Future<void> _delete(Transaction tx) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.bgCard,
        title: const Text('Delete transaction?',
            style: TextStyle(color: AppColors.textPrimary)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel',
                  style: TextStyle(color: AppColors.textSecondary))),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Delete',
                  style: TextStyle(color: AppColors.expense))),
        ],
      ),
    );
    if (confirm == true) {
      await DBHelper.instance.deleteTransaction(tx.id!);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final grouped = _groupByDate();
    final sortedKeys = grouped.keys.toList()..sort((a, b) => b.compareTo(a));

    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        title: const Text('MyMoney',
            style: TextStyle(
                color: AppColors.gold,
                fontWeight: FontWeight.w700,
                fontSize: 22,
                fontStyle: FontStyle.italic)),
        backgroundColor: AppColors.bgHeader,
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: AppColors.textPrimary),
            onPressed: () {},
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _openAdd,
        backgroundColor: const Color(0xFF555544),
        child: const Icon(Icons.add, color: AppColors.gold),
      ),
      body: Column(
        children: [
          // Month navigator
          Container(
            color: AppColors.bgHeader,
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: MonthNavigator(
              current: _month,
              onChanged: (d) {
                setState(() => _month = d);
                _load();
              },
            ),
          ),

          // Summary bar
          SummaryBar(expense: _expense, income: _income),

          // Transactions
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(color: AppColors.gold))
                : _transactions.isEmpty
                    ? const Center(
                        child: Text('No records this month',
                            style: TextStyle(color: AppColors.textSecondary)))
                    : ListView.builder(
                        itemCount: sortedKeys.length,
                        itemBuilder: (_, i) {
                          final key = sortedKeys[i];
                          final txs = grouped[key]!;
                          final date = DateTime.parse(key);
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SectionHeader(
                                  title: formatDateHeader(date)),
                              ...txs.map((tx) => Dismissible(
                                    key: Key('tx_${tx.id}'),
                                    direction:
                                        DismissDirection.endToStart,
                                    background: Container(
                                      color: AppColors.expense,
                                      alignment: Alignment.centerRight,
                                      padding: const EdgeInsets.only(
                                          right: 20),
                                      child: const Icon(Icons.delete,
                                          color: Colors.white),
                                    ),
                                    confirmDismiss: (_) async {
                                      await _delete(tx);
                                      return false;
                                    },
                                    child: TransactionTile(
                                      tx: tx,
                                      onTap: () => _openEdit(tx),
                                    ),
                                  )),
                            ],
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
