import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/models.dart';
import '../../utils/theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/common_widgets.dart';
import '../records/add_transaction_screen.dart';

class AccountsScreen extends StatefulWidget {
  const AccountsScreen({super.key});

  @override
  State<AccountsScreen> createState() => _AccountsScreenState();
}

class _AccountsScreenState extends State<AccountsScreen> {
  List<Account> _accounts = [];
  Map<int, double> _balances = {};
  double _allAccountsTotal = 0;
  double _expense = 0, _income = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final now = DateTime.now();
    final accounts = await DBHelper.instance.getAccounts();
    final Map<int, double> balances = {};
    for (final a in accounts) {
      balances[a.id!] = await DBHelper.instance.getAccountBalance(a.id!);
    }
    final total = await DBHelper.instance.getTotalAllAccounts();
    final summary = await DBHelper.instance.getMonthSummary(now.month, now.year);

    setState(() {
      _accounts = accounts;
      _balances = balances;
      _allAccountsTotal = total;
      _expense = summary['expense'] ?? 0;
      _income = summary['income'] ?? 0;
      _loading = false;
    });
  }

  Future<void> _showAddAccount() async {
    final nameCtrl = TextEditingController();
    final balanceCtrl = TextEditingController(text: '0');

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.bgCard,
        title: const Text('Add Account', style: TextStyle(color: AppColors.gold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtrl,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: const InputDecoration(
                labelText: 'Account name',
                labelStyle: TextStyle(color: AppColors.textSecondary),
                enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.border)),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.gold)),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: balanceCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: const InputDecoration(
                labelText: 'Initial balance (₦)',
                labelStyle: TextStyle(color: AppColors.textSecondary),
                enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.border)),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.gold)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel',
                  style: TextStyle(color: AppColors.textSecondary))),
          TextButton(
            onPressed: () async {
              if (nameCtrl.text.trim().isEmpty) return;
              await DBHelper.instance.insertAccount(Account(
                name: nameCtrl.text.trim(),
                initialBalance: double.tryParse(balanceCtrl.text) ?? 0,
              ));
              Navigator.pop(context);
              _load();
            },
            child: const Text('Add', style: TextStyle(color: AppColors.gold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        title: const Text('MyMoney',
            style: TextStyle(
                color: AppColors.gold,
                fontWeight: FontWeight.w700,
                fontSize: 22,
                fontStyle: FontStyle.italic)),
        backgroundColor: AppColors.bgHeader,
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: AppColors.textPrimary),
            onPressed: () {},
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddAccount,
        backgroundColor: const Color(0xFF555544),
        child: const Icon(Icons.add, color: AppColors.gold),
      ),
      body: Column(
        children: [
          // All accounts total
          Container(
            color: AppColors.bgHeader,
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Column(
              children: [
                Text(
                  '[ All Accounts ${_allAccountsTotal < 0 ? '-' : ''}${formatAmount(_allAccountsTotal)} ]',
                  style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w600,
                      fontSize: 15),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Column(children: [
                      const Text('EXPENSE SO FAR',
                          style: TextStyle(color: AppColors.textSecondary, fontSize: 11, fontWeight: FontWeight.w600)),
                      Text(formatAmount(_expense),
                          style: const TextStyle(color: AppColors.expense, fontWeight: FontWeight.w700)),
                    ]),
                    Column(children: [
                      const Text('INCOME SO FAR',
                          style: TextStyle(color: AppColors.textSecondary, fontSize: 11, fontWeight: FontWeight.w600)),
                      Text(formatAmount(_income),
                          style: const TextStyle(color: AppColors.income, fontWeight: FontWeight.w700)),
                    ]),
                  ],
                ),
              ],
            ),
          ),

          const SectionHeader(title: 'Accounts'),

          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: AppColors.gold))
                : _accounts.isEmpty
                    ? const Center(child: Text('No accounts yet',
                        style: TextStyle(color: AppColors.textSecondary)))
                    : ListView.builder(
                        padding: const EdgeInsets.only(bottom: 80, left: 12, right: 12),
                        itemCount: _accounts.length,
                        itemBuilder: (_, i) {
                          final a = _accounts[i];
                          final balance = _balances[a.id] ?? 0;
                          return _accountCard(a, balance);
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _accountCard(Account a, double balance) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => AccountDetailScreen(account: a)),
      ).then((_) => _load()),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            AccountIcon(iconName: a.iconName, colorHex: a.colorHex),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(a.name,
                      style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontWeight: FontWeight.w700,
                          fontSize: 15)),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      const Text('Balance: ',
                          style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                      Text(formatAmount(balance),
                          style: TextStyle(
                              color: balance >= 0 ? AppColors.income : AppColors.expense,
                              fontWeight: FontWeight.w700,
                              fontSize: 12)),
                    ],
                  ),
                ],
              ),
            ),
            IconButton(
              icon: const Icon(Icons.more_vert, color: AppColors.textSecondary),
              onPressed: () => _showAccountMenu(a),
            ),
          ],
        ),
      ),
    );
  }

  void _showAccountMenu(Account a) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.bgCard,
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.delete, color: AppColors.expense),
            title: const Text('Delete account',
                style: TextStyle(color: AppColors.textPrimary)),
            onTap: () async {
              await DBHelper.instance.deleteAccount(a.id!);
              Navigator.pop(context);
              _load();
            },
          ),
        ],
      ),
    );
  }
}

// ─── Account Detail ───────────────────────────────────────────────────────

class AccountDetailScreen extends StatefulWidget {
  final Account account;
  const AccountDetailScreen({super.key, required this.account});

  @override
  State<AccountDetailScreen> createState() => _AccountDetailScreenState();
}

class _AccountDetailScreenState extends State<AccountDetailScreen> {
  List<Transaction> _txs = [];
  double _balance = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final txs = await DBHelper.instance.getTransactions(accountId: widget.account.id);
    final bal = await DBHelper.instance.getAccountBalance(widget.account.id!);
    setState(() {
      _txs = txs;
      _balance = bal;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        backgroundColor: AppColors.bgHeader,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Account details',
                style: TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w700)),
            Text('Records: All time',
                style: TextStyle(color: AppColors.textSecondary, fontSize: 11)),
          ],
        ),
        leading: IconButton(
          icon: const Icon(Icons.close, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.gold))
          : ListView(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      AccountIcon(iconName: widget.account.iconName, colorHex: widget.account.colorHex, size: 60),
                      const SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(widget.account.name,
                              style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w700, fontSize: 18)),
                          Row(children: [
                            const Text('Account balance: ', style: TextStyle(color: AppColors.textSecondary)),
                            Text(formatAmount(_balance),
                                style: TextStyle(
                                    color: _balance >= 0 ? AppColors.income : AppColors.expense,
                                    fontWeight: FontWeight.w700)),
                          ]),
                          Row(children: [
                            const Text('Initially: ', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                            Text(formatAmount(widget.account.initialBalance),
                                style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                          ]),
                        ],
                      ),
                    ],
                  ),
                ),

                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.bgInput,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.info_outline, color: AppColors.textSecondary, size: 16),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'You can see Monthly, weekly, or daily statistics of this account in the Analysis section.',
                          style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                if (_txs.isEmpty)
                  const Center(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Text('No record in this account',
                          style: TextStyle(color: AppColors.textSecondary)),
                    ),
                  )
                else ...[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                    child: Row(
                      children: [
                        Text('Total ${_txs.length} records in this account',
                            style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w700)),
                        const Spacer(),
                        const Icon(Icons.sort, color: AppColors.textSecondary, size: 14),
                        const SizedBox(width: 4),
                        const Text('NEW TO OLD',
                            style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                      ],
                    ),
                  ),
                  ..._txs.map((tx) => TransactionTile(tx: tx)),
                ],
              ],
            ),
    );
  }
}
