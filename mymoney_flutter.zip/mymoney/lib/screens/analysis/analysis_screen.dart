import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'dart:math';
import '../../db/db_helper.dart';
import '../../utils/theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/common_widgets.dart';
import '../records/add_transaction_screen.dart';

enum AnalysisMode { expenseOverview, incomeOverview, expenseFlow, incomeFlow, accountAnalysis }

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({super.key});

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {
  DateTime _month = DateTime.now();
  AnalysisMode _mode = AnalysisMode.expenseOverview;
  double _expense = 0, _income = 0;
  List<Map<String, dynamic>> _data = [];
  List<Map<String, dynamic>> _dailyData = [];
  bool _loading = true;

  final _modeLabels = {
    AnalysisMode.expenseOverview: 'EXPENSE OVERVIEW',
    AnalysisMode.incomeOverview: 'INCOME OVERVIEW',
    AnalysisMode.expenseFlow: 'EXPENSE FLOW',
    AnalysisMode.incomeFlow: 'INCOME FLOW',
    AnalysisMode.accountAnalysis: 'ACCOUNT ANALYSIS',
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final summary = await DBHelper.instance.getMonthSummary(_month.month, _month.year);

    List<Map<String, dynamic>> data = [];
    List<Map<String, dynamic>> daily = [];

    switch (_mode) {
      case AnalysisMode.expenseOverview:
        data = await DBHelper.instance.getCategoryTotals(
            type: 'expense', month: _month.month, year: _month.year);
        break;
      case AnalysisMode.incomeOverview:
        data = await DBHelper.instance.getCategoryTotals(
            type: 'income', month: _month.month, year: _month.year);
        break;
      case AnalysisMode.expenseFlow:
        daily = await DBHelper.instance.getDailyTotals(
            type: 'expense', month: _month.month, year: _month.year);
        break;
      case AnalysisMode.incomeFlow:
        daily = await DBHelper.instance.getDailyTotals(
            type: 'income', month: _month.month, year: _month.year);
        break;
      case AnalysisMode.accountAnalysis:
        data = await DBHelper.instance.getAccountTotals(
            month: _month.month, year: _month.year);
        break;
    }

    setState(() {
      _expense = summary['expense'] ?? 0;
      _income = summary['income'] ?? 0;
      _data = data;
      _dailyData = daily;
      _loading = false;
    });
  }

  void _changeMode(AnalysisMode mode) {
    setState(() => _mode = mode);
    _load();
    Navigator.pop(context);
  }

  void _showModeMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.bgCard,
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: AnalysisMode.values.map((m) => ListTile(
          title: Text(_modeLabels[m]!,
              style: const TextStyle(color: AppColors.textPrimary)),
          onTap: () => _changeMode(m),
        )).toList(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(context,
              MaterialPageRoute(builder: (_) => const AddTransactionScreen()));
          if (result == true) _load();
        },
        backgroundColor: const Color(0xFF555544),
        child: const Icon(Icons.add, color: AppColors.gold),
      ),
      body: Column(
        children: [
          // Month nav + summary
          Container(
            color: AppColors.bgHeader,
            child: MonthNavigator(
              current: _month,
              onChanged: (d) { setState(() => _month = d); _load(); },
            ),
          ),
          SummaryBar(expense: _expense, income: _income),

          // Mode selector
          Padding(
            padding: const EdgeInsets.all(12),
            child: GestureDetector(
              onTap: _showModeMenu,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.gold),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.keyboard_arrow_down, color: AppColors.gold, size: 18),
                    const SizedBox(width: 8),
                    Text(_modeLabels[_mode]!,
                        style: const TextStyle(
                            color: AppColors.gold,
                            fontWeight: FontWeight.w700,
                            fontSize: 14)),
                  ],
                ),
              ),
            ),
          ),

          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: AppColors.gold))
                : _buildContent(),
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    switch (_mode) {
      case AnalysisMode.expenseOverview:
        return _buildOverview('expense');
      case AnalysisMode.incomeOverview:
        return _buildOverview('income');
      case AnalysisMode.expenseFlow:
        return _buildFlow(AppColors.expense);
      case AnalysisMode.incomeFlow:
        return _buildFlow(AppColors.income);
      case AnalysisMode.accountAnalysis:
        return _buildAccountAnalysis();
    }
  }

  Widget _buildOverview(String type) {
    if (_data.isEmpty) {
      return const Center(child: Text('No data this month',
          style: TextStyle(color: AppColors.textSecondary)));
    }

    final total = _data.fold<double>(0, (s, d) => s + (d['total'] as num).toDouble());
    final colors = [
      AppColors.expense, AppColors.income, AppColors.transfer,
      const Color(0xFFF9A825), const Color(0xFF9C27B0), const Color(0xFF00BCD4),
    ];

    final sections = _data.asMap().entries.map((e) {
      final pct = total > 0 ? (e.value['total'] as num).toDouble() / total : 0.0;
      return PieChartSectionData(
        value: (e.value['total'] as num).toDouble(),
        color: colors[e.key % colors.length],
        radius: 50,
        showTitle: false,
      );
    }).toList();

    return ListView(
      children: [
        SizedBox(
          height: 220,
          child: Row(
            children: [
              Expanded(
                child: PieChart(PieChartData(
                  sections: sections,
                  centerSpaceRadius: 55,
                  sectionsSpace: 2,
                )),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: _data.asMap().entries.map((e) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(
                    children: [
                      Container(width: 12, height: 12,
                          color: colors[e.key % colors.length]),
                      const SizedBox(width: 6),
                      Text(e.value['name'] ?? '',
                          style: const TextStyle(
                              color: AppColors.textPrimary, fontSize: 12)),
                    ],
                  ),
                )).toList(),
              ),
              const SizedBox(width: 16),
            ],
          ),
        ),
        const Divider(color: AppColors.border),
        ..._data.asMap().entries.map((e) {
          final amount = (e.value['total'] as num).toDouble();
          final pct = total > 0 ? amount / total * 100 : 0.0;
          final color = colors[e.key % colors.length];
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Column(
              children: [
                Row(
                  children: [
                    CategoryIcon(
                        iconName: e.value['icon_name'] ?? 'label',
                        colorHex: e.value['color_hex'] ?? '#9E9E9E'),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(child: Text(e.value['name'] ?? '',
                                  style: const TextStyle(
                                      color: AppColors.textPrimary,
                                      fontWeight: FontWeight.w600))),
                              Text(formatAmount(amount),
                                  style: TextStyle(
                                      color: type == 'expense'
                                          ? AppColors.expense
                                          : AppColors.income,
                                      fontWeight: FontWeight.w700)),
                              const SizedBox(width: 8),
                              Text('${pct.toStringAsFixed(2)}%',
                                  style: const TextStyle(
                                      color: AppColors.textSecondary,
                                      fontSize: 12)),
                            ],
                          ),
                          const SizedBox(height: 4),
                          LinearProgressIndicator(
                            value: pct / 100,
                            backgroundColor: AppColors.bgInput,
                            valueColor: AlwaysStoppedAnimation(color),
                            minHeight: 6,
                            borderRadius: BorderRadius.circular(3),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const Divider(color: AppColors.border, height: 16),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _buildFlow(Color color) {
    final daysInMonth = DateUtils.getDaysInMonth(_month.year, _month.month);
    final Map<int, double> dayMap = {};
    for (final d in _dailyData) {
      dayMap[int.parse(d['day'].toString())] = (d['total'] as num).toDouble();
    }

    final spots = List.generate(daysInMonth, (i) {
      final day = i + 1;
      return FlSpot(day.toDouble(), dayMap[day] ?? 0);
    });

    final maxY = spots.map((s) => s.y).reduce(max);

    return ListView(
      children: [
        // Line chart
        Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            height: 200,
            child: LineChart(LineChartData(
              gridData: const FlGridData(show: false),
              borderData: FlBorderData(show: false),
              titlesData: FlTitlesData(
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (v, m) => Text(
                      v == 0 ? '₦0' : '−₦${(v / 1000).toStringAsFixed(0)}k',
                      style: const TextStyle(
                          color: AppColors.textSecondary, fontSize: 9),
                    ),
                    reservedSize: 60,
                  ),
                ),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    interval: 7,
                    getTitlesWidget: (v, m) => Text(
                      'Jun ${v.toInt().toString().padLeft(2, '0')}',
                      style: const TextStyle(
                          color: AppColors.textSecondary, fontSize: 9),
                    ),
                  ),
                ),
                rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false)),
                topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false)),
              ),
              lineBarsData: [
                LineChartBarData(
                  spots: spots,
                  color: color,
                  barWidth: 1.5,
                  dotData: FlDotData(
                    getDotPainter: (s, _, __, ___) => FlDotCirclePainter(
                      radius: 3,
                      color: s.y > 0 ? color : Colors.transparent,
                      strokeColor: s.y > 0 ? color : Colors.transparent,
                      strokeWidth: 1,
                    ),
                  ),
                  belowBarData: BarAreaData(
                    show: true,
                    color: color.withOpacity(0.15),
                  ),
                ),
              ],
              minY: 0,
              maxY: maxY > 0 ? maxY * 1.2 : 100,
            )),
          ),
        ),
        // Mini calendar
        _buildCalendar(dayMap, color),
      ],
    );
  }

  Widget _buildCalendar(Map<int, double> dayMap, Color color) {
    final daysInMonth = DateUtils.getDaysInMonth(_month.year, _month.month);
    final firstWeekday = DateTime(_month.year, _month.month, 1).weekday % 7;

    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(formatMonthYear(_month),
              style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w700,
                  fontSize: 14)),
          const SizedBox(height: 8),
          Row(
            children: ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map((d) =>
              Expanded(child: Center(child: Text(d,
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 11))))).toList(),
          ),
          const SizedBox(height: 4),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 7, childAspectRatio: 1),
            itemCount: firstWeekday + daysInMonth,
            itemBuilder: (_, i) {
              if (i < firstWeekday) return const SizedBox();
              final day = i - firstWeekday + 1;
              final amount = dayMap[day];
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('$day', style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 11)),
                  if (amount != null && amount > 0)
                    Text(
                      amount >= 1000
                          ? '-${(amount / 1000).toStringAsFixed(1)}k'
                          : '-${amount.toInt()}',
                      style: TextStyle(color: color, fontSize: 9),
                    )
                  else
                    Container(width: 4, height: 4,
                        decoration: BoxDecoration(
                            color: AppColors.textMuted,
                            shape: BoxShape.circle)),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildAccountAnalysis() {
    if (_data.isEmpty) {
      return const Center(child: Text('No data',
          style: TextStyle(color: AppColors.textSecondary)));
    }

    final maxVal = _data.fold<double>(0, (m, d) {
      final exp = (d['expense'] as num).toDouble();
      final inc = (d['income'] as num).toDouble();
      return [m, exp, inc].reduce(max);
    });

    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            height: 200,
            child: BarChart(BarChartData(
              maxY: maxVal > 0 ? maxVal * 1.2 : 100,
              gridData: const FlGridData(show: false),
              borderData: FlBorderData(show: false),
              titlesData: FlTitlesData(
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (v, m) {
                      final idx = v.toInt();
                      if (idx >= _data.length) return const SizedBox();
                      final name = (_data[idx]['name'] as String);
                      return Transform.rotate(
                        angle: -0.5,
                        child: Text(
                          name.length > 6 ? '${name.substring(0, 6)}...' : name,
                          style: const TextStyle(
                              color: AppColors.textSecondary, fontSize: 8),
                        ),
                      );
                    },
                    reservedSize: 30,
                  ),
                ),
                leftTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false)),
                rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false)),
                topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false)),
              ),
              barGroups: _data.asMap().entries.map((e) {
                final exp = (e.value['expense'] as num).toDouble();
                final inc = (e.value['income'] as num).toDouble();
                return BarChartGroupData(
                  x: e.key,
                  barRods: [
                    if (exp > 0) BarChartRodData(toY: exp, color: AppColors.expense, width: 8, borderRadius: BorderRadius.circular(2)),
                    if (inc > 0) BarChartRodData(toY: inc, color: AppColors.income, width: 8, borderRadius: BorderRadius.circular(2)),
                  ],
                );
              }).toList(),
            )),
          ),
        ),

        // Legend
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Icon(Icons.square, color: AppColors.expense, size: 12),
              SizedBox(width: 4),
              Text('Expense', style: TextStyle(color: AppColors.textSecondary, fontSize: 11)),
              SizedBox(width: 16),
              Icon(Icons.square, color: AppColors.income, size: 12),
              SizedBox(width: 4),
              Text('Income', style: TextStyle(color: AppColors.textSecondary, fontSize: 11)),
            ],
          ),
        ),
        const SizedBox(height: 8),
        const Divider(color: AppColors.border),

        ..._data.map((d) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(
            children: [
              AccountIcon(
                  iconName: d['icon_name'] ?? 'wallet',
                  colorHex: d['color_hex'] ?? '#4CAF50'),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(d['name'] ?? '',
                        style: const TextStyle(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColors.expense),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            '-${formatAmount((d['expense'] as num).toDouble())}',
                            style: const TextStyle(
                                color: AppColors.expense, fontSize: 11),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColors.income),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            formatAmount((d['income'] as num).toDouble()),
                            style: const TextStyle(
                                color: AppColors.income, fontSize: 11),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        )),
      ],
    );
  }
}
