// ─── Account ────────────────────────────────────────────────────────────────
class Account {
  final int? id;
  final String name;
  final double initialBalance;
  final String iconName;
  final String colorHex;

  Account({
    this.id,
    required this.name,
    required this.initialBalance,
    this.iconName = 'wallet',
    this.colorHex = '#4CAF50',
  });

  double get balance => initialBalance; // computed in DB layer

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'initial_balance': initialBalance,
        'icon_name': iconName,
        'color_hex': colorHex,
      };

  factory Account.fromMap(Map<String, dynamic> m) => Account(
        id: m['id'],
        name: m['name'],
        initialBalance: (m['initial_balance'] as num).toDouble(),
        iconName: m['icon_name'] ?? 'wallet',
        colorHex: m['color_hex'] ?? '#4CAF50',
      );

  Account copyWith({
    int? id,
    String? name,
    double? initialBalance,
    String? iconName,
    String? colorHex,
  }) =>
      Account(
        id: id ?? this.id,
        name: name ?? this.name,
        initialBalance: initialBalance ?? this.initialBalance,
        iconName: iconName ?? this.iconName,
        colorHex: colorHex ?? this.colorHex,
      );
}

// ─── Category ───────────────────────────────────────────────────────────────
class Category {
  final int? id;
  final String name;
  final String type; // 'income' | 'expense'
  final String iconName;
  final String colorHex;
  final bool isIgnored;

  Category({
    this.id,
    required this.name,
    required this.type,
    this.iconName = 'label',
    this.colorHex = '#9E9E9E',
    this.isIgnored = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'type': type,
        'icon_name': iconName,
        'color_hex': colorHex,
        'is_ignored': isIgnored ? 1 : 0,
      };

  factory Category.fromMap(Map<String, dynamic> m) => Category(
        id: m['id'],
        name: m['name'],
        type: m['type'],
        iconName: m['icon_name'] ?? 'label',
        colorHex: m['color_hex'] ?? '#9E9E9E',
        isIgnored: (m['is_ignored'] ?? 0) == 1,
      );

  Category copyWith({
    int? id,
    String? name,
    String? type,
    String? iconName,
    String? colorHex,
    bool? isIgnored,
  }) =>
      Category(
        id: id ?? this.id,
        name: name ?? this.name,
        type: type ?? this.type,
        iconName: iconName ?? this.iconName,
        colorHex: colorHex ?? this.colorHex,
        isIgnored: isIgnored ?? this.isIgnored,
      );
}

// ─── Transaction ─────────────────────────────────────────────────────────────
class Transaction {
  final int? id;
  final String type; // 'income' | 'expense' | 'transfer'
  final double amount;
  final int? accountId;
  final int? categoryId;
  final int? toAccountId; // for transfers
  final String? note;
  final DateTime date;

  // Joined fields (not stored)
  final String? accountName;
  final String? categoryName;
  final String? categoryIcon;
  final String? categoryColor;
  final String? toAccountName;

  Transaction({
    this.id,
    required this.type,
    required this.amount,
    this.accountId,
    this.categoryId,
    this.toAccountId,
    this.note,
    required this.date,
    this.accountName,
    this.categoryName,
    this.categoryIcon,
    this.categoryColor,
    this.toAccountName,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'type': type,
        'amount': amount,
        'account_id': accountId,
        'category_id': categoryId,
        'to_account_id': toAccountId,
        'note': note,
        'date': date.toIso8601String(),
      };

  factory Transaction.fromMap(Map<String, dynamic> m) => Transaction(
        id: m['id'],
        type: m['type'],
        amount: (m['amount'] as num).toDouble(),
        accountId: m['account_id'],
        categoryId: m['category_id'],
        toAccountId: m['to_account_id'],
        note: m['note'],
        date: DateTime.parse(m['date']),
        accountName: m['account_name'],
        categoryName: m['category_name'],
        categoryIcon: m['category_icon'],
        categoryColor: m['category_color'],
        toAccountName: m['to_account_name'],
      );
}

// ─── Budget ──────────────────────────────────────────────────────────────────
class Budget {
  final int? id;
  final int categoryId;
  final double limitAmount;
  final int month; // 1-12
  final int year;

  // Joined
  final String? categoryName;
  final String? categoryIcon;
  final String? categoryColor;
  final double spent;

  Budget({
    this.id,
    required this.categoryId,
    required this.limitAmount,
    required this.month,
    required this.year,
    this.categoryName,
    this.categoryIcon,
    this.categoryColor,
    this.spent = 0,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'category_id': categoryId,
        'limit_amount': limitAmount,
        'month': month,
        'year': year,
      };

  factory Budget.fromMap(Map<String, dynamic> m) => Budget(
        id: m['id'],
        categoryId: m['category_id'],
        limitAmount: (m['limit_amount'] as num).toDouble(),
        month: m['month'],
        year: m['year'],
        categoryName: m['category_name'],
        categoryIcon: m['category_icon'],
        categoryColor: m['category_color'],
        spent: (m['spent'] as num?)?.toDouble() ?? 0,
      );
}
