# MyMoney - Flutter App

An offline-first personal finance tracker inspired by the MyMoney app.

## Features

- ✅ Record income, expenses, and transfers
- ✅ Built-in calculator keypad for entering amounts
- ✅ Multiple accounts (bank, cash, wallets, etc.)
- ✅ Income & expense categories with icons
- ✅ Monthly budget limits per category
- ✅ Analysis: donut charts, flow line charts, calendar view, account analysis
- ✅ 100% offline — all data stored locally via SQLite
- ✅ Dark olive/gold theme matching MyMoney's aesthetic

---

## Setup Instructions

### 1. Install Flutter

Download Flutter SDK from https://flutter.dev/docs/get-started/install

Make sure you have:
- Flutter 3.10+
- Android Studio or Xcode (for iOS)
- A connected device or emulator

### 2. Install dependencies

```bash
cd mymoney
flutter pub get
```

### 3. Run the app

```bash
# Android
flutter run

# iOS
flutter run -d ios

# List available devices
flutter devices
```

### 4. Build a release APK (Android)

```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

### 5. Build for iOS

```bash
flutter build ios --release
# Then open ios/Runner.xcworkspace in Xcode to archive and distribute
```

---

## Project Structure

```
lib/
├── main.dart                    # App entry + bottom nav shell
├── models/
│   └── models.dart              # Account, Category, Transaction, Budget
├── db/
│   └── db_helper.dart           # SQLite CRUD operations
├── utils/
│   ├── theme.dart               # Colors, typography, ThemeData
│   └── formatters.dart          # Currency, date, icon helpers
├── widgets/
│   └── common_widgets.dart      # Reusable UI components
└── screens/
    ├── records/
    │   ├── records_screen.dart         # Main transaction list
    │   └── add_transaction_screen.dart # Add/edit with calculator
    ├── analysis/
    │   └── analysis_screen.dart        # Charts & reports
    ├── budgets/
    │   └── budgets_screen.dart         # Monthly budget management
    ├── accounts/
    │   └── accounts_screen.dart        # Account list + detail
    └── categories/
        └── categories_screen.dart      # Category list + detail
```

---

## Customization

**Currency symbol:** Search for `₦` in `lib/utils/formatters.dart` and replace with your symbol (e.g. `$`, `€`, `£`).

**Default categories:** Edit `_seedCategories()` in `lib/db/db_helper.dart`.

**Colors:** All colors are in `lib/utils/theme.dart` → `AppColors`.
