import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/models.dart';
import '../../utils/theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/common_widgets.dart';
import '../records/add_transaction_screen.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;
  List<Category> _income = [], _expense = [];
  double _expenseSoFar = 0, _incomeSoFar = 0, _allAccountsTotal = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this, initialIndex: 0);
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final now = DateTime.now();
    final income = await DBHelper.instance.getCategories(type: 'income');
    final expense = await DBHelper.instance.getCategories(type: 'expense');
    final summary = await DBHelper.instance.getMonthSummary(now.month, now.year);
    final total = await DBHelper.instance.getTotalAllAccounts();

    setState(() {
      _income = income;
      _expense = expense;
      _expenseSoFar = summary['expense'] ?? 0;
      _incomeSoFar = summary['income'] ?? 0;
      _allAccountsTotal = total;
      _loading = false;
    });
  }

  Future<void> _showAddCategory(String type) async {
    final nameCtrl = TextEditingController();
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.bgCard,
        title: Text('Add ${type[0].toUpperCase()}${type.substring(1)} Category',
            style: const TextStyle(color: AppColors.gold)),
        content: TextField(
          controller: nameCtrl,
          style: const TextStyle(color: AppColors.textPrimary),
          decoration: const InputDecoration(
            labelText: 'Category name',
            labelStyle: TextStyle(color: AppColors.textSecondary),
            enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: AppColors.border)),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: AppColors.gold)),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel',
                  style: TextStyle(color: AppColors.textSecondary))),
          TextButton(
            onPressed: () async {
              if (nameCtrl.text.trim().isEmpty) return;
              await DBHelper.instance.insertCategory(Category(
                name: nameCtrl.text.trim(),
                type: type,
              ));
              Navigator.pop(context);
              _load();
            },
            child: const Text('Add', style: TextStyle(color: AppColors.gold)),
          ),
        ],
      ),
    );
  }

  void _showCategoryMenu(Category cat) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.bgCard,
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            title: const Text('Edit', style: TextStyle(color: AppColors.textPrimary)),
            onTap: () async {
              Navigator.pop(context);
              await _editCategory(cat);
            },
          ),
          ListTile(
            title: const Text('Delete', style: TextStyle(color: AppColors.expense)),
            onTap: () async {
              await DBHelper.instance.deleteCategory(cat.id!);
              Navigator.pop(context);
              _load();
            },
          ),
          ListTile(
            title: Text(cat.isIgnored ? 'Unignore' : 'Ignore',
                style: const TextStyle(color: AppColors.textSecondary)),
            onTap: () async {
              await DBHelper.instance.updateCategory(cat.copyWith(isIgnored: !cat.isIgnored));
              Navigator.pop(context);
              _load();
            },
          ),
        ],
      ),
    );
  }

  Future<void> _editCategory(Category cat) async {
    final nameCtrl = TextEditingController(text: cat.name);
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.bgCard,
        title: const Text('Edit Category', style: TextStyle(color: AppColors.gold)),
        content: TextField(
          controller: nameCtrl,
          style: const TextStyle(color: AppColors.textPrimary),
          decoration: const InputDecoration(
            labelText: 'Category name',
            labelStyle: TextStyle(color: AppColors.textSecondary),
            enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: AppColors.border)),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: AppColors.gold)),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel',
                  style: TextStyle(color: AppColors.textSecondary))),
          TextButton(
            onPressed: () async {
              await DBHelper.instance.updateCategory(cat.copyWith(name: nameCtrl.text.trim()));
              Navigator.pop(context);
              _load();
            },
            child: const Text('Save', style: TextStyle(color: AppColors.gold)),
          ),
        ],
      ),
    );
  }

  Widget _categoryList(List<Category> cats, String type) {
    final active = cats.where((c) => !c.isIgnored).toList();
    final ignored = cats.where((c) => c.isIgnored).toList();

    return Stack(
      children: [
        ListView(
          padding: const EdgeInsets.only(bottom: 80),
          children: [
            if (active.isNotEmpty) ...[
              SectionHeader(title: '${type[0].toUpperCase()}${type.substring(1)} categories'),
              ...active.map((c) => _categoryTile(c)),
            ],
            if (ignored.isNotEmpty) ...[
              const SectionHeader(title: 'Ignored'),
              ...ignored.map((c) => _categoryTile(c)),
            ],
          ],
        ),
        Positioned(
          bottom: 16,
          right: 16,
          child: FloatingActionButton(
            heroTag: 'fab_$type',
            onPressed: () => _showAddCategory(type),
            backgroundColor: const Color(0xFF555544),
            child: const Icon(Icons.add, color: AppColors.gold),
          ),
        ),
      ],
    );
  }

  Widget _categoryTile(Category cat) {
    return ListTile(
      leading: CategoryIcon(iconName: cat.iconName, colorHex: cat.colorHex),
      title: Text(
        cat.isIgnored ? '.${cat.name}' : cat.name,
        style: TextStyle(
          color: cat.isIgnored ? AppColors.textMuted : AppColors.textPrimary,
          fontWeight: FontWeight.w600,
          decoration: cat.isIgnored ? TextDecoration.lineThrough : null,
        ),
      ),
      trailing: IconButton(
        icon: const Icon(Icons.more_horiz, color: AppColors.textSecondary),
        onPressed: () => _showCategoryMenu(cat),
      ),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => CategoryDetailScreen(category: cat)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        title: const Text('MyMoney',
            style: TextStyle(
                color: AppColors.gold,
                fontWeight: FontWeight.w700,
                fontSize: 22,
                fontStyle: FontStyle.italic)),
        backgroundColor: AppColors.bgHeader,
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: AppColors.textPrimary),
            onPressed: () {},
          ),
        ],
        bottom: TabBar(
          controller: _tabs,
          labelColor: AppColors.gold,
          unselectedLabelColor: AppColors.textSecondary,
          indicatorColor: AppColors.gold,
          tabs: const [Tab(text: 'INCOME'), Tab(text: 'EXPENSE')],
        ),
      ),
      body: Column(
        children: [
          // Stats bar
          Container(
            color: AppColors.bgHeader,
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Column(
              children: [
                Text(
                  '[ All Accounts ${_allAccountsTotal < 0 ? '-' : ''}${formatAmount(_allAccountsTotal)} ]',
                  style: const TextStyle(
                      color: AppColors.textPrimary, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Column(children: [
                      const Text('EXPENSE SO FAR',
                          style: TextStyle(color: AppColors.textSecondary, fontSize: 11, fontWeight: FontWeight.w600)),
                      Text(formatAmount(_expenseSoFar),
                          style: const TextStyle(color: AppColors.expense, fontWeight: FontWeight.w700)),
                    ]),
                    Column(children: [
                      const Text('INCOME SO FAR',
                          style: TextStyle(color: AppColors.textSecondary, fontSize: 11, fontWeight: FontWeight.w600)),
                      Text(formatAmount(_incomeSoFar),
                          style: const TextStyle(color: AppColors.income, fontWeight: FontWeight.w700)),
                    ]),
                  ],
                ),
              ],
            ),
          ),

          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: AppColors.gold))
                : TabBarView(
                    controller: _tabs,
                    children: [
                      _categoryList(_income, 'income'),
                      _categoryList(_expense, 'expense'),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}

// ─── Category Detail ──────────────────────────────────────────────────────

class CategoryDetailScreen extends StatefulWidget {
  final Category category;
  const CategoryDetailScreen({super.key, required this.category});

  @override
  State<CategoryDetailScreen> createState() => _CategoryDetailScreenState();
}

class _CategoryDetailScreenState extends State<CategoryDetailScreen> {
  List<Transaction> _txs = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final txs = await DBHelper.instance.getTransactions(categoryId: widget.category.id);
    setState(() {
      _txs = txs;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        backgroundColor: AppColors.bgHeader,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Category details',
                style: TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w700)),
            Text('Records: All time',
                style: TextStyle(color: AppColors.textSecondary, fontSize: 11)),
          ],
        ),
        leading: IconButton(
          icon: const Icon(Icons.close, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.gold))
          : ListView(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      CategoryIcon(iconName: widget.category.iconName, colorHex: widget.category.colorHex, size: 56),
                      const SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(widget.category.name,
                              style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w700, fontSize: 18)),
                          Text('${widget.category.type[0].toUpperCase()}${widget.category.type.substring(1)} category',
                              style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                        ],
                      ),
                    ],
                  ),
                ),

                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.bgInput,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.info_outline, color: AppColors.textSecondary, size: 16),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'You can see Monthly, weekly, or daily statistics in the Analysis section.',
                          style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                if (_txs.isEmpty)
                  const Center(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Text('No records in this category',
                          style: TextStyle(color: AppColors.textSecondary)),
                    ),
                  )
                else ...[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                    child: Row(
                      children: [
                        Text('Total ${_txs.length} records in this category',
                            style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w700)),
                        const Spacer(),
                        const Icon(Icons.sort, color: AppColors.textSecondary, size: 14),
                        const SizedBox(width: 4),
                        const Text('NEW TO OLD',
                            style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                      ],
                    ),
                  ),
                  ..._txs.map((tx) => TransactionTile(tx: tx)),
                ],
              ],
            ),
    );
  }
}
