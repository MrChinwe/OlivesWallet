import 'package:flutter/material.dart';
import '../utils/theme.dart';
import '../utils/formatters.dart';
import '../models/models.dart';

// ─── Category Icon Circle ─────────────────────────────────────────────────

class CategoryIcon extends StatelessWidget {
  final String iconName;
  final String colorHex;
  final double size;

  const CategoryIcon({
    super.key,
    required this.iconName,
    required this.colorHex,
    this.size = 44,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: hexColor(colorHex),
        shape: BoxShape.circle,
      ),
      child: Icon(
        iconFromName(iconName),
        color: Colors.white,
        size: size * 0.52,
      ),
    );
  }
}

// ─── Account Icon Square ──────────────────────────────────────────────────

class AccountIcon extends StatelessWidget {
  final String iconName;
  final String colorHex;
  final double size;

  const AccountIcon({
    super.key,
    required this.iconName,
    required this.colorHex,
    this.size = 52,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: hexColor(colorHex).withOpacity(0.15),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: hexColor(colorHex).withOpacity(0.3)),
      ),
      child: Icon(
        iconFromName(iconName),
        color: hexColor(colorHex),
        size: size * 0.5,
      ),
    );
  }
}

// ─── Transaction Tile ─────────────────────────────────────────────────────

class TransactionTile extends StatelessWidget {
  final Transaction tx;
  final VoidCallback? onTap;

  const TransactionTile({super.key, required this.tx, this.onTap});

  @override
  Widget build(BuildContext context) {
    final isTransfer = tx.type == 'transfer';
    final color = amountColor(tx.type);

    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: [
            isTransfer
                ? Container(
                    width: 44,
                    height: 44,
                    decoration: const BoxDecoration(
                      color: AppColors.transfer,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.swap_horiz,
                        color: Colors.white, size: 22),
                  )
                : CategoryIcon(
                    iconName: tx.categoryIcon ?? 'label',
                    colorHex: tx.categoryColor ?? '#9E9E9E',
                  ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isTransfer
                        ? 'Transfer'
                        : (tx.categoryName ?? '—'),
                    style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      if (tx.accountName != null)
                        Icon(Icons.account_balance_wallet,
                            size: 11, color: AppColors.textSecondary),
                      if (tx.accountName != null)
                        Text(' ${tx.accountName}',
                            style: const TextStyle(
                                color: AppColors.textSecondary, fontSize: 11)),
                      if (isTransfer && tx.toAccountName != null)
                        Text(' → ${tx.toAccountName}',
                            style: const TextStyle(
                                color: AppColors.textSecondary, fontSize: 11)),
                      if (tx.note != null && tx.note!.isNotEmpty)
                        Text(
                          '  " ${tx.note} "',
                          style: const TextStyle(
                              color: AppColors.textSecondary, fontSize: 11),
                          overflow: TextOverflow.ellipsis,
                        ),
                    ],
                  ),
                ],
              ),
            ),
            Text(
              formatAmount(tx.amount),
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w700,
                fontSize: 15,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Section Header ───────────────────────────────────────────────────────

class SectionHeader extends StatelessWidget {
  final String title;

  const SectionHeader({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w700,
              fontSize: 14,
            ),
          ),
          const Divider(color: AppColors.border, thickness: 0.5, height: 8),
        ],
      ),
    );
  }
}

// ─── Summary Header Bar ───────────────────────────────────────────────────

class SummaryBar extends StatelessWidget {
  final double expense;
  final double income;

  const SummaryBar({super.key, required this.expense, required this.income});

  @override
  Widget build(BuildContext context) {
    final total = income - expense;
    return Container(
      color: AppColors.bgHeader,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _item('EXPENSE', expense, AppColors.expense),
          _item('INCOME', income, AppColors.income),
          _item('TOTAL', total, total >= 0 ? AppColors.income : AppColors.expense),
        ],
      ),
    );
  }

  Widget _item(String label, double value, Color color) {
    return Column(
      children: [
        Text(label,
            style: const TextStyle(
                color: AppColors.textSecondary,
                fontSize: 11,
                fontWeight: FontWeight.w600)),
        const SizedBox(height: 2),
        Text(
          '${value < 0 ? '-' : ''}${formatAmount(value)}',
          style: TextStyle(
              color: color, fontWeight: FontWeight.w700, fontSize: 13),
        ),
      ],
    );
  }
}

// ─── Month Navigator ──────────────────────────────────────────────────────

class MonthNavigator extends StatelessWidget {
  final DateTime current;
  final ValueChanged<DateTime> onChanged;

  const MonthNavigator(
      {super.key, required this.current, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton(
          icon: const Icon(Icons.chevron_left, color: AppColors.textPrimary),
          onPressed: () => onChanged(
              DateTime(current.year, current.month - 1)),
        ),
        Text(
          formatMonthYear(current),
          style: const TextStyle(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w600,
              fontSize: 16),
        ),
        IconButton(
          icon: const Icon(Icons.chevron_right, color: AppColors.textPrimary),
          onPressed: () => onChanged(
              DateTime(current.year, current.month + 1)),
        ),
      ],
    );
  }
}

// ─── Gold Button ──────────────────────────────────────────────────────────

class GoldOutlineButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  final IconData? icon;

  const GoldOutlineButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        side: const BorderSide(color: AppColors.gold),
        foregroundColor: AppColors.gold,
        padding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[Icon(icon, size: 16), const SizedBox(width: 6)],
          Text(label,
              style: const TextStyle(
                  fontWeight: FontWeight.w700, fontSize: 13)),
        ],
      ),
    );
  }
}
