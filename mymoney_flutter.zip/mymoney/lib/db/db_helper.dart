import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/models.dart';

class DBHelper {
  static final DBHelper instance = DBHelper._internal();
  static Database? _db;

  DBHelper._internal();

  Future<Database> get db async {
    _db ??= await _initDB();
    return _db!;
  }

  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'mymoney.db');

    return openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        initial_balance REAL DEFAULT 0,
        icon_name TEXT DEFAULT 'wallet',
        color_hex TEXT DEFAULT '#4CAF50'
      )
    ''');

    await db.execute('''
      CREATE TABLE categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        icon_name TEXT DEFAULT 'label',
        color_hex TEXT DEFAULT '#9E9E9E',
        is_ignored INTEGER DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        account_id INTEGER,
        category_id INTEGER,
        to_account_id INTEGER,
        note TEXT,
        date TEXT NOT NULL,
        FOREIGN KEY (account_id) REFERENCES accounts(id),
        FOREIGN KEY (category_id) REFERENCES categories(id),
        FOREIGN KEY (to_account_id) REFERENCES accounts(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE budgets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL,
        limit_amount REAL NOT NULL,
        month INTEGER NOT NULL,
        year INTEGER NOT NULL,
        FOREIGN KEY (category_id) REFERENCES categories(id),
        UNIQUE(category_id, month, year)
      )
    ''');

    // Seed default categories
    await _seedCategories(db);
  }

  Future<void> _seedCategories(Database db) async {
    final expenseCategories = [
      {'name': 'General', 'icon_name': 'groups', 'color_hex': '#4CAF50'},
      {'name': 'Food & Dining', 'icon_name': 'restaurant', 'color_hex': '#FF7043'},
      {'name': 'Transportation', 'icon_name': 'directions_bus', 'color_hex': '#1565C0'},
      {'name': 'Shopping', 'icon_name': 'shopping_bag', 'color_hex': '#AB47BC'},
      {'name': 'Bills & Utilities', 'icon_name': 'receipt', 'color_hex': '#F57F17'},
      {'name': 'Health', 'icon_name': 'medical_services', 'color_hex': '#E53935'},
      {'name': 'Entertainment', 'icon_name': 'movie', 'color_hex': '#00897B'},
      {'name': 'Education', 'icon_name': 'school', 'color_hex': '#1E88E5'},
    ];

    final incomeCategories = [
      {'name': 'Salary', 'icon_name': 'account_balance_wallet', 'color_hex': '#7B3F00'},
      {'name': 'Side Gigs', 'icon_name': 'card_giftcard', 'color_hex': '#2E7D32'},
      {'name': 'Loans', 'icon_name': 'attach_money', 'color_hex': '#1B5E20'},
      {'name': 'Refunds', 'icon_name': 'attach_money', 'color_hex': '#1B5E20'},
      {'name': 'Rental', 'icon_name': 'home', 'color_hex': '#4A148C'},
    ];

    for (final cat in expenseCategories) {
      await db.insert('categories', {
        ...cat,
        'type': 'expense',
        'is_ignored': 0,
      });
    }

    for (final cat in incomeCategories) {
      await db.insert('categories', {
        ...cat,
        'type': 'income',
        'is_ignored': 0,
      });
    }

    // Default accounts
    await db.insert('accounts', {
      'name': 'Cash',
      'initial_balance': 0,
      'icon_name': 'account_balance_wallet',
      'color_hex': '#F9A825',
    });
  }

  // ─── ACCOUNTS ─────────────────────────────────────────────────────────────

  Future<List<Account>> getAccounts() async {
    final d = await db;
    final rows = await d.query('accounts', orderBy: 'name ASC');
    return rows.map(Account.fromMap).toList();
  }

  Future<Account?> getAccount(int id) async {
    final d = await db;
    final rows = await d.query('accounts', where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty ? null : Account.fromMap(rows.first);
  }

  Future<double> getAccountBalance(int accountId) async {
    final d = await db;
    final acc = await d.query('accounts',
        where: 'id = ?', whereArgs: [accountId]);
    if (acc.isEmpty) return 0;
    final initial = (acc.first['initial_balance'] as num).toDouble();

    final incomeRes = await d.rawQuery('''
      SELECT COALESCE(SUM(amount), 0) as total FROM transactions
      WHERE account_id = ? AND type = 'income'
    ''', [accountId]);
    final transferInRes = await d.rawQuery('''
      SELECT COALESCE(SUM(amount), 0) as total FROM transactions
      WHERE to_account_id = ? AND type = 'transfer'
    ''', [accountId]);
    final expenseRes = await d.rawQuery('''
      SELECT COALESCE(SUM(amount), 0) as total FROM transactions
      WHERE account_id = ? AND type = 'expense'
    ''', [accountId]);
    final transferOutRes = await d.rawQuery('''
      SELECT COALESCE(SUM(amount), 0) as total FROM transactions
      WHERE account_id = ? AND type = 'transfer'
    ''', [accountId]);

    final incomeTotal = (incomeRes.first['total'] as num).toDouble();
    final transferIn = (transferInRes.first['total'] as num).toDouble();
    final expenseTotal = (expenseRes.first['total'] as num).toDouble();
    final transferOut = (transferOutRes.first['total'] as num).toDouble();

    return initial + incomeTotal + transferIn - expenseTotal - transferOut;
  }

  Future<int> insertAccount(Account a) async {
    final d = await db;
    return d.insert('accounts', a.toMap()..remove('id'));
  }

  Future<void> updateAccount(Account a) async {
    final d = await db;
    await d.update('accounts', a.toMap(), where: 'id = ?', whereArgs: [a.id]);
  }

  Future<void> deleteAccount(int id) async {
    final d = await db;
    await d.delete('accounts', where: 'id = ?', whereArgs: [id]);
  }

  // ─── CATEGORIES ───────────────────────────────────────────────────────────

  Future<List<Category>> getCategories({String? type}) async {
    final d = await db;
    final where = type != null ? 'type = ?' : null;
    final args = type != null ? [type] : null;
    final rows = await d.query('categories',
        where: where, whereArgs: args, orderBy: 'is_ignored ASC, name ASC');
    return rows.map(Category.fromMap).toList();
  }

  Future<int> insertCategory(Category c) async {
    final d = await db;
    return d.insert('categories', c.toMap()..remove('id'));
  }

  Future<void> updateCategory(Category c) async {
    final d = await db;
    await d.update('categories', c.toMap(),
        where: 'id = ?', whereArgs: [c.id]);
  }

  Future<void> deleteCategory(int id) async {
    final d = await db;
    await d.delete('categories', where: 'id = ?', whereArgs: [id]);
  }

  // ─── TRANSACTIONS ─────────────────────────────────────────────────────────

  Future<List<Transaction>> getTransactions({
    int? month,
    int? year,
    int? accountId,
    int? categoryId,
  }) async {
    final d = await db;
    String where = '1=1';
    final args = <dynamic>[];

    if (month != null && year != null) {
      where += " AND strftime('%m', t.date) = ? AND strftime('%Y', t.date) = ?";
      args.add(month.toString().padLeft(2, '0'));
      args.add(year.toString());
    }
    if (accountId != null) {
      where += ' AND (t.account_id = ? OR t.to_account_id = ?)';
      args.addAll([accountId, accountId]);
    }
    if (categoryId != null) {
      where += ' AND t.category_id = ?';
      args.add(categoryId);
    }

    final rows = await d.rawQuery('''
      SELECT 
        t.*,
        a.name as account_name,
        c.name as category_name,
        c.icon_name as category_icon,
        c.color_hex as category_color,
        ta.name as to_account_name
      FROM transactions t
      LEFT JOIN accounts a ON t.account_id = a.id
      LEFT JOIN categories c ON t.category_id = c.id
      LEFT JOIN accounts ta ON t.to_account_id = ta.id
      WHERE $where
      ORDER BY t.date DESC, t.id DESC
    ''', args);

    return rows.map(Transaction.fromMap).toList();
  }

  Future<Map<String, double>> getMonthSummary(int month, int year) async {
    final d = await db;
    final m = month.toString().padLeft(2, '0');
    final y = year.toString();

    final expRes = await d.rawQuery('''
      SELECT COALESCE(SUM(amount), 0) as total FROM transactions
      WHERE type = 'expense'
      AND strftime('%m', date) = ? AND strftime('%Y', date) = ?
    ''', [m, y]);

    final incRes = await d.rawQuery('''
      SELECT COALESCE(SUM(amount), 0) as total FROM transactions
      WHERE type = 'income'
      AND strftime('%m', date) = ? AND strftime('%Y', date) = ?
    ''', [m, y]);

    return {
      'expense': (expRes.first['total'] as num).toDouble(),
      'income': (incRes.first['total'] as num).toDouble(),
    };
  }

  Future<double> getTotalAllAccounts() async {
    final accounts = await getAccounts();
    double total = 0;
    for (final a in accounts) {
      total += await getAccountBalance(a.id!);
    }
    return total;
  }

  Future<int> insertTransaction(Transaction t) async {
    final d = await db;
    return d.insert('transactions', t.toMap()..remove('id'));
  }

  Future<void> updateTransaction(Transaction t) async {
    final d = await db;
    await d.update('transactions', t.toMap(),
        where: 'id = ?', whereArgs: [t.id]);
  }

  Future<void> deleteTransaction(int id) async {
    final d = await db;
    await d.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }

  // ─── BUDGETS ──────────────────────────────────────────────────────────────

  Future<List<Budget>> getBudgets(int month, int year) async {
    final d = await db;
    final m = month.toString().padLeft(2, '0');
    final y = year.toString();

    final rows = await d.rawQuery('''
      SELECT 
        b.*,
        c.name as category_name,
        c.icon_name as category_icon,
        c.color_hex as category_color,
        COALESCE((
          SELECT SUM(t.amount) FROM transactions t
          WHERE t.category_id = b.category_id AND t.type = 'expense'
          AND strftime('%m', t.date) = ? AND strftime('%Y', t.date) = ?
        ), 0) as spent
      FROM budgets b
      LEFT JOIN categories c ON b.category_id = c.id
      WHERE b.month = ? AND b.year = ?
    ''', [m, y, month, year]);

    return rows.map(Budget.fromMap).toList();
  }

  Future<int> insertBudget(Budget b) async {
    final d = await db;
    return d.insert('budgets', b.toMap()..remove('id'),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteBudget(int id) async {
    final d = await db;
    await d.delete('budgets', where: 'id = ?', whereArgs: [id]);
  }

  // ─── ANALYSIS ─────────────────────────────────────────────────────────────

  Future<List<Map<String, dynamic>>> getCategoryTotals({
    required String type,
    required int month,
    required int year,
  }) async {
    final d = await db;
    final m = month.toString().padLeft(2, '0');
    final y = year.toString();

    return d.rawQuery('''
      SELECT 
        c.id, c.name, c.icon_name, c.color_hex,
        COALESCE(SUM(t.amount), 0) as total
      FROM categories c
      LEFT JOIN transactions t ON t.category_id = c.id
        AND t.type = ?
        AND strftime('%m', t.date) = ?
        AND strftime('%Y', t.date) = ?
      WHERE c.type = ? AND c.is_ignored = 0
      GROUP BY c.id
      HAVING total > 0
      ORDER BY total DESC
    ''', [type, m, y, type]);
  }

  Future<List<Map<String, dynamic>>> getDailyTotals({
    required String type,
    required int month,
    required int year,
  }) async {
    final d = await db;
    final m = month.toString().padLeft(2, '0');
    final y = year.toString();

    return d.rawQuery('''
      SELECT 
        strftime('%d', date) as day,
        COALESCE(SUM(amount), 0) as total
      FROM transactions
      WHERE type = ?
        AND strftime('%m', date) = ?
        AND strftime('%Y', date) = ?
      GROUP BY day
      ORDER BY day ASC
    ''', [type, m, y]);
  }

  Future<List<Map<String, dynamic>>> getAccountTotals({
    required int month,
    required int year,
  }) async {
    final d = await db;
    final m = month.toString().padLeft(2, '0');
    final y = year.toString();

    return d.rawQuery('''
      SELECT 
        a.id, a.name, a.icon_name, a.color_hex,
        COALESCE(SUM(CASE WHEN t.type='expense' AND t.account_id=a.id THEN t.amount ELSE 0 END), 0) as expense,
        COALESCE(SUM(CASE WHEN t.type='income' AND t.account_id=a.id THEN t.amount ELSE 0 END), 0) as income
      FROM accounts a
      LEFT JOIN transactions t ON (t.account_id = a.id OR t.to_account_id = a.id)
        AND strftime('%m', t.date) = ?
        AND strftime('%Y', t.date) = ?
      GROUP BY a.id
      ORDER BY a.name ASC
    ''', [m, y]);
  }

  // ─── RESET ────────────────────────────────────────────────────────────────

  Future<void> deleteAllData() async {
    final d = await db;
    await d.delete('transactions');
    await d.delete('budgets');
    await d.delete('accounts');
    await d.delete('categories');
    await _seedCategories(d);
  }
}
