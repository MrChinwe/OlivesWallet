import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/models.dart';
import '../utils/theme.dart';
import '../utils/formatters.dart';

class AddTransactionScreen extends StatefulWidget {
  final Transaction? existing;
  const AddTransactionScreen({super.key, this.existing});

  @override
  State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}

class _AddTransactionScreenState extends State<AddTransactionScreen> {
  String _type = 'expense';
  Account? _account;
  Account? _toAccount;
  Category? _category;
  String _displayValue = '0';
  String _expression = '';
  final _noteController = TextEditingController();
  DateTime _date = DateTime.now();
  List<Account> _accounts = [];
  List<Category> _categories = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
    if (widget.existing != null) {
      final tx = widget.existing!;
      _type = tx.type;
      _displayValue = tx.amount.toStringAsFixed(2);
      _noteController.text = tx.note ?? '';
      _date = tx.date;
    }
  }

  Future<void> _loadData() async {
    final accounts = await DBHelper.instance.getAccounts();
    final categories = await DBHelper.instance.getCategories();
    setState(() {
      _accounts = accounts;
      _categories = categories;
      if (widget.existing != null) {
        _account = accounts.firstWhere(
            (a) => a.id == widget.existing!.accountId,
            orElse: () => accounts.first);
        if (widget.existing!.categoryId != null) {
          _category = categories.firstWhere(
              (c) => c.id == widget.existing!.categoryId,
              orElse: () => categories.first);
        }
        if (widget.existing!.toAccountId != null) {
          _toAccount = accounts.firstWhere(
              (a) => a.id == widget.existing!.toAccountId,
              orElse: () => accounts.first);
        }
      } else if (accounts.isNotEmpty) {
        _account = accounts.first;
      }
      _loading = false;
    });
  }

  void _onKey(String key) {
    setState(() {
      if (key == '⌫') {
        if (_displayValue.length > 1) {
          _displayValue = _displayValue.substring(0, _displayValue.length - 1);
        } else {
          _displayValue = '0';
        }
        return;
      }
      if (key == '=') {
        _evaluate();
        return;
      }
      if (['+', '-', '×', '÷'].contains(key)) {
        _expression = _displayValue + key;
        _displayValue = '0';
        return;
      }
      if (key == '.') {
        if (!_displayValue.contains('.')) {
          _displayValue += '.';
        }
        return;
      }
      if (_displayValue == '0') {
        _displayValue = key;
      } else {
        _displayValue += key;
      }
    });
  }

  void _evaluate() {
    if (_expression.isEmpty) return;
    try {
      final op = _expression[_expression.length - 1];
      final left = double.parse(_expression.substring(0, _expression.length - 1));
      final right = double.parse(_displayValue);
      double result;
      switch (op) {
        case '+': result = left + right; break;
        case '-': result = left - right; break;
        case '×': result = left * right; break;
        case '÷': result = right != 0 ? left / right : left; break;
        default: return;
      }
      _displayValue = result % 1 == 0
          ? result.toInt().toString()
          : result.toStringAsFixed(2);
      _expression = '';
    } catch (_) {}
  }

  Future<void> _save() async {
    final amount = double.tryParse(_displayValue) ?? 0;
    if (amount <= 0) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Enter a valid amount')));
      return;
    }
    if (_account == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Select an account')));
      return;
    }

    final tx = Transaction(
      id: widget.existing?.id,
      type: _type,
      amount: amount,
      accountId: _account!.id,
      categoryId: _type != 'transfer' ? _category?.id : null,
      toAccountId: _type == 'transfer' ? _toAccount?.id : null,
      note: _noteController.text.trim().isEmpty ? null : _noteController.text.trim(),
      date: _date,
    );

    if (widget.existing == null) {
      await DBHelper.instance.insertTransaction(tx);
    } else {
      await DBHelper.instance.updateTransaction(tx);
    }

    if (mounted) Navigator.pop(context, true);
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      builder: (ctx, child) => Theme(
        data: ThemeData.dark().copyWith(
          colorScheme: const ColorScheme.dark(primary: AppColors.gold),
        ),
        child: child!,
      ),
    );
    if (picked != null) setState(() => _date = picked);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
          body: Center(child: CircularProgressIndicator(color: AppColors.gold)));
    }

    final filteredCategories =
        _categories.where((c) => c.type == _type && !c.isIgnored).toList();

    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        backgroundColor: AppColors.bgHeader,
        leading: TextButton.icon(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.close, color: AppColors.gold, size: 18),
          label: const Text('CANCEL',
              style: TextStyle(color: AppColors.gold, fontSize: 13)),
        ),
        leadingWidth: 100,
        title: const SizedBox.shrink(),
        actions: [
          TextButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.check, color: AppColors.gold, size: 18),
            label: const Text('SAVE',
                style: TextStyle(color: AppColors.gold, fontSize: 13)),
          ),
        ],
      ),
      body: Column(
        children: [
          // Type selector
          Container(
            color: AppColors.bgHeader,
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: ['income', 'expense', 'transfer'].map((t) {
                final active = _type == t;
                return GestureDetector(
                  onTap: () => setState(() => _type = t),
                  child: Row(
                    children: [
                      if (active)
                        const Icon(Icons.check_circle,
                            color: AppColors.gold, size: 18),
                      const SizedBox(width: 4),
                      Text(
                        t.toUpperCase(),
                        style: TextStyle(
                          color: active
                              ? AppColors.gold
                              : AppColors.textSecondary,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),

          // Account & Category pickers
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Account',
                          style: TextStyle(
                              color: AppColors.textSecondary, fontSize: 11)),
                      const SizedBox(height: 4),
                      _pickerBox(
                        icon: Icons.account_balance_wallet,
                        label: _account?.name ?? 'Account',
                        onTap: () => _showAccountPicker(false),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                          _type == 'transfer' ? 'To Account' : 'Category',
                          style: const TextStyle(
                              color: AppColors.textSecondary, fontSize: 11)),
                      const SizedBox(height: 4),
                      _type == 'transfer'
                          ? _pickerBox(
                              icon: Icons.account_balance_wallet,
                              label: _toAccount?.name ?? 'To Account',
                              onTap: () => _showAccountPicker(true),
                            )
                          : _pickerBox(
                              icon: Icons.label,
                              label: _category?.name ?? 'Category',
                              onTap: () => _showCategoryPicker(filteredCategories),
                            ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Notes
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Container(
              height: 80,
              decoration: BoxDecoration(
                color: AppColors.bgInput,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.border),
              ),
              child: TextField(
                controller: _noteController,
                style: const TextStyle(color: AppColors.textPrimary),
                maxLines: 3,
                decoration: const InputDecoration(
                  hintText: 'Add notes',
                  hintStyle: TextStyle(color: AppColors.textMuted),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.all(10),
                ),
              ),
            ),
          ),

          const SizedBox(height: 8),

          // Display
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 12),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.bgInput,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                if (_expression.isNotEmpty)
                  Text(_expression,
                      style: const TextStyle(
                          color: AppColors.textSecondary, fontSize: 16)),
                const Spacer(),
                Text(
                  _displayValue,
                  style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 32,
                      fontWeight: FontWeight.w300),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () => _onKey('⌫'),
                  child: const Icon(Icons.backspace_outlined,
                      color: AppColors.textSecondary),
                ),
              ],
            ),
          ),

          const SizedBox(height: 8),

          // Keypad
          Expanded(
            child: _buildKeypad(),
          ),

          // Date/Time row
          GestureDetector(
            onTap: _pickDate,
            child: Container(
              color: AppColors.bgHeader,
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text(formatDate(_date),
                      style: const TextStyle(
                          color: AppColors.textPrimary, fontSize: 14)),
                  Container(
                      height: 20, width: 1, color: AppColors.border),
                  Text(
                    '${_date.hour.toString().padLeft(2, '0')}:${_date.minute.toString().padLeft(2, '0')} ${_date.hour < 12 ? 'AM' : 'PM'}',
                    style: const TextStyle(
                        color: AppColors.textPrimary, fontSize: 14),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _pickerBox(
      {required IconData icon, required String label, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.bgInput,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppColors.textSecondary, size: 18),
            const SizedBox(width: 8),
            Expanded(
              child: Text(label,
                  style: const TextStyle(
                      color: AppColors.textPrimary, fontSize: 13),
                  overflow: TextOverflow.ellipsis),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildKeypad() {
    final keys = [
      ['+', '7', '8', '9'],
      ['-', '4', '5', '6'],
      ['×', '1', '2', '3'],
      ['÷', '0', '.', '='],
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Column(
        children: keys.map((row) {
          return Expanded(
            child: Row(
              children: row.map((key) {
                final isOp = ['+', '-', '×', '÷'].contains(key);
                final isEq = key == '=';
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(2),
                    child: Material(
                      color: isOp || isEq
                          ? AppColors.bgCalcOp
                          : AppColors.bgCalcKey,
                      borderRadius: BorderRadius.circular(6),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(6),
                        onTap: () => _onKey(key),
                        child: Center(
                          child: Text(
                            key,
                            style: const TextStyle(
                              color: AppColors.textPrimary,
                              fontSize: 20,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          );
        }).toList(),
      ),
    );
  }

  void _showAccountPicker(bool isTo) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.bgCard,
      builder: (_) => ListView(
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('Select Account',
                style: TextStyle(
                    color: AppColors.gold,
                    fontWeight: FontWeight.w700,
                    fontSize: 16)),
          ),
          ..._accounts.map((a) => ListTile(
                leading: const Icon(Icons.account_balance_wallet,
                    color: AppColors.textSecondary),
                title: Text(a.name,
                    style: const TextStyle(color: AppColors.textPrimary)),
                onTap: () {
                  setState(() {
                    if (isTo) {
                      _toAccount = a;
                    } else {
                      _account = a;
                    }
                  });
                  Navigator.pop(context);
                },
              )),
        ],
      ),
    );
  }

  void _showCategoryPicker(List<Category> cats) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.bgCard,
      builder: (_) => ListView(
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('Select Category',
                style: TextStyle(
                    color: AppColors.gold,
                    fontWeight: FontWeight.w700,
                    fontSize: 16)),
          ),
          ...cats.map((c) => ListTile(
                leading: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: hexColor(c.colorHex),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(iconFromName(c.iconName),
                      color: Colors.white, size: 16),
                ),
                title: Text(c.name,
                    style: const TextStyle(color: AppColors.textPrimary)),
                onTap: () {
                  setState(() => _category = c);
                  Navigator.pop(context);
                },
              )),
        ],
      ),
    );
  }
}
