import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  // Backgrounds
  static const Color bgDark = Color(0xFF2E2E22);
  static const Color bgCard = Color(0xFF3A3A2A);
  static const Color bgHeader = Color(0xFF252518);
  static const Color bgInput = Color(0xFF333325);
  static const Color bgCalcKey = Color(0xFF4A4A38);
  static const Color bgCalcOp = Color(0xFF5A5A44);

  // Brand
  static const Color gold = Color(0xFFC9A84C);
  static const Color goldLight = Color(0xFFE8C96A);

  // Semantic
  static const Color income = Color(0xFF4CAF50);
  static const Color expense = Color(0xFFE57373);
  static const Color transfer = Color(0xFF64B5F6);

  // Text
  static const Color textPrimary = Color(0xFFEEEEDD);
  static const Color textSecondary = Color(0xFF999977);
  static const Color textMuted = Color(0xFF666655);

  // Border
  static const Color border = Color(0xFF4A4A38);
}

class AppTheme {
  static ThemeData get dark {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.bgDark,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.gold,
        secondary: AppColors.income,
        surface: AppColors.bgCard,
        error: AppColors.expense,
      ),
      textTheme: GoogleFonts.nunitoTextTheme(
        const TextTheme(
          displayLarge: TextStyle(color: AppColors.textPrimary),
          bodyLarge: TextStyle(color: AppColors.textPrimary),
          bodyMedium: TextStyle(color: AppColors.textPrimary),
        ),
      ).apply(
        bodyColor: AppColors.textPrimary,
        displayColor: AppColors.textPrimary,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.bgHeader,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        titleTextStyle: TextStyle(
          color: AppColors.gold,
          fontSize: 22,
          fontWeight: FontWeight.w700,
          fontFamily: 'Georgia',
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.bgHeader,
        selectedItemColor: AppColors.gold,
        unselectedItemColor: AppColors.textSecondary,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: Color(0xFF555544),
        foregroundColor: AppColors.gold,
      ),
      dividerColor: AppColors.border,
      cardColor: AppColors.bgCard,
    );
  }
}
