import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import '../utils/theme.dart';

String formatAmount(double amount, {bool showSign = false}) {
  final formatter = NumberFormat('#,##0.00');
  final str = '₦${formatter.format(amount.abs())}';
  if (showSign && amount < 0) return '-$str';
  return str;
}

String formatDate(DateTime date) {
  return DateFormat('MMM d, yyyy').format(date);
}

String formatDateHeader(DateTime date) {
  return DateFormat('MMM d, EEEE').format(date);
}

String formatMonthYear(DateTime date) {
  return DateFormat('MMMM yyyy').format(date);
}

Color amountColor(String type) {
  switch (type) {
    case 'income':
      return AppColors.income;
    case 'expense':
      return AppColors.expense;
    case 'transfer':
      return AppColors.transfer;
    default:
      return AppColors.textPrimary;
  }
}

IconData iconFromName(String name) {
  const map = {
    'wallet': Icons.account_balance_wallet,
    'account_balance_wallet': Icons.account_balance_wallet,
    'groups': Icons.groups,
    'restaurant': Icons.restaurant,
    'directions_bus': Icons.directions_bus,
    'shopping_bag': Icons.shopping_bag,
    'receipt': Icons.receipt,
    'medical_services': Icons.medical_services,
    'movie': Icons.movie,
    'school': Icons.school,
    'attach_money': Icons.attach_money,
    'home': Icons.home,
    'card_giftcard': Icons.card_giftcard,
    'label': Icons.label,
    'swap_horiz': Icons.swap_horiz,
    'savings': Icons.savings,
    'phone_android': Icons.phone_android,
    'star': Icons.star,
  };
  return map[name] ?? Icons.label;
}

Color hexColor(String hex) {
  try {
    final h = hex.replaceAll('#', '');
    return Color(int.parse('FF$h', radix: 16));
  } catch (_) {
    return Colors.grey;
  }
}
