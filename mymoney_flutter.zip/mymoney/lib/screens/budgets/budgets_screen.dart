import 'package:flutter/material.dart';
import '../../db/db_helper.dart';
import '../../models/models.dart';
import '../../utils/theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/common_widgets.dart';
import '../records/add_transaction_screen.dart';

class BudgetsScreen extends StatefulWidget {
  const BudgetsScreen({super.key});

  @override
  State<BudgetsScreen> createState() => _BudgetsScreenState();
}

class _BudgetsScreenState extends State<BudgetsScreen> {
  DateTime _month = DateTime.now();
  List<Budget> _budgets = [];
  List<Category> _unbudgeted = [];
  double _totalBudget = 0, _totalSpent = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final budgets = await DBHelper.instance.getBudgets(_month.month, _month.year);
    final allCats = await DBHelper.instance.getCategories(type: 'expense');
    final budgetedIds = budgets.map((b) => b.categoryId).toSet();
    final unbudgeted = allCats.where((c) => !budgetedIds.contains(c.id) && !c.isIgnored).toList();

    setState(() {
      _budgets = budgets;
      _unbudgeted = unbudgeted;
      _totalBudget = budgets.fold(0, (s, b) => s + b.limitAmount);
      _totalSpent = budgets.fold(0, (s, b) => s + b.spent);
      _loading = false;
    });
  }

  Future<void> _showSetBudget(Category cat) async {
    final ctrl = TextEditingController();
    final result = await showDialog<double>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.bgCard,
        title: Text('Budget for ${cat.name}',
            style: const TextStyle(color: AppColors.gold)),
        content: TextField(
          controller: ctrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          style: const TextStyle(color: AppColors.textPrimary),
          decoration: const InputDecoration(
            hintText: 'Amount (₦)',
            hintStyle: TextStyle(color: AppColors.textMuted),
            enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: AppColors.border)),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: AppColors.gold)),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel',
                  style: TextStyle(color: AppColors.textSecondary))),
          TextButton(
            onPressed: () {
              final v = double.tryParse(ctrl.text);
              Navigator.pop(context, v);
            },
            child: const Text('Set', style: TextStyle(color: AppColors.gold)),
          ),
        ],
      ),
    );

    if (result != null && result > 0) {
      await DBHelper.instance.insertBudget(Budget(
        categoryId: cat.id!,
        limitAmount: result,
        month: _month.month,
        year: _month.year,
      ));
      _load();
    }
  }

  Future<void> _copyFromPast() async {
    final prev = DateTime(_month.year, _month.month - 1);
    final prevBudgets = await DBHelper.instance.getBudgets(prev.month, prev.year);
    if (prevBudgets.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('No budgets found in previous month')));
      }
      return;
    }
    for (final b in prevBudgets) {
      await DBHelper.instance.insertBudget(Budget(
        categoryId: b.categoryId,
        limitAmount: b.limitAmount,
        month: _month.month,
        year: _month.year,
      ));
    }
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        title: const Text('MyMoney',
            style: TextStyle(
                color: AppColors.gold,
                fontWeight: FontWeight.w700,
                fontSize: 22,
                fontStyle: FontStyle.italic)),
        backgroundColor: AppColors.bgHeader,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(context,
              MaterialPageRoute(builder: (_) => const AddTransactionScreen()));
          if (result == true) _load();
        },
        backgroundColor: const Color(0xFF555544),
        child: const Icon(Icons.add, color: AppColors.gold),
      ),
      body: Column(
        children: [
          Container(
            color: AppColors.bgHeader,
            child: MonthNavigator(
              current: _month,
              onChanged: (d) { setState(() => _month = d); _load(); },
            ),
          ),

          // Total budget/spent
          Container(
            color: AppColors.bgHeader,
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(children: [
                  const Text('TOTAL BUDGET',
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 11, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text(formatAmount(_totalBudget),
                      style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w700)),
                ]),
                Column(children: [
                  const Text('TOTAL SPENT',
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 11, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text(formatAmount(_totalSpent),
                      style: const TextStyle(color: AppColors.expense, fontWeight: FontWeight.w700)),
                ]),
              ],
            ),
          ),

          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: AppColors.gold))
                : ListView(
                    padding: const EdgeInsets.only(bottom: 80),
                    children: [
                      if (_budgets.isNotEmpty) ...[
                        SectionHeader(title: 'Budgeted categories: ${formatMonthYear(_month)}'),
                        ..._budgets.map((b) => _budgetTile(b)),
                      ],

                      if (_budgets.isEmpty)
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Text(
                            'Currently, no budget is applied for this month.\nSet budget-limits for this month, or copy your budget-limits from past months.',
                            style: const TextStyle(color: AppColors.textSecondary),
                            textAlign: TextAlign.center,
                          ),
                        ),

                      if (_unbudgeted.isNotEmpty) ...[
                        const SectionHeader(title: 'Not budgeted this month'),
                        ..._unbudgeted.map((cat) => Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          child: Row(
                            children: [
                              CategoryIcon(iconName: cat.iconName, colorHex: cat.colorHex),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(cat.name,
                                    style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w600)),
                              ),
                              GoldOutlineButton(
                                label: 'SET BUDGET',
                                onPressed: () => _showSetBudget(cat),
                              ),
                            ],
                          ),
                        )),
                      ],

                      const SizedBox(height: 16),
                      Center(
                        child: GoldOutlineButton(
                          label: 'SET FROM PAST MONTHS',
                          icon: Icons.add_circle_outline,
                          onPressed: _copyFromPast,
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _budgetTile(Budget b) {
    final progress = b.limitAmount > 0 ? (b.spent / b.limitAmount).clamp(0.0, 1.0) : 0.0;
    final overBudget = b.spent > b.limitAmount;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          CategoryIcon(iconName: b.categoryIcon ?? 'label', colorHex: b.categoryColor ?? '#9E9E9E'),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(child: Text(b.categoryName ?? '',
                        style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w600))),
                    Text(formatAmount(b.limitAmount),
                        style: const TextStyle(color: AppColors.gold, fontSize: 12)),
                  ],
                ),
                const SizedBox(height: 4),
                LinearProgressIndicator(
                  value: progress,
                  backgroundColor: AppColors.bgInput,
                  valueColor: AlwaysStoppedAnimation(
                      overBudget ? AppColors.expense : AppColors.gold),
                  minHeight: 5,
                  borderRadius: BorderRadius.circular(3),
                ),
                const SizedBox(height: 2),
                Text(
                  'Spent: ${formatAmount(b.spent)} of ${formatAmount(b.limitAmount)}',
                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 11),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.more_vert, color: AppColors.textSecondary, size: 18),
            onPressed: () => _showBudgetMenu(b),
          ),
        ],
      ),
    );
  }

  void _showBudgetMenu(Budget b) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.bgCard,
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.delete, color: AppColors.expense),
            title: const Text('Delete budget',
                style: TextStyle(color: AppColors.textPrimary)),
            onTap: () async {
              await DBHelper.instance.deleteBudget(b.id!);
              Navigator.pop(context);
              _load();
            },
          ),
        ],
      ),
    );
  }
}
